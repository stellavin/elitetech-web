import ClientLogoItem from "./clientLogo/item"

const AgencyClientLogo=()=>{
return(
<>
<div className="ag-client-logo-style">
<div className="container">
<div className="ag-client-logo-row">
    <ClientLogoItem/>
    <ClientLogoItem/>
    <ClientLogoItem/>
    <ClientLogoItem/>
    <ClientLogoItem/>
</div>
</div>
</div>
</>
)
}
export default AgencyClientLogo