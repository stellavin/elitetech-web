import BlogItem from "./BlogItem"

const Blogs=()=>{
return(
<>
<div className="row align-items-center g-4 g-lg-4 g-md-4 g-sm-4 g-xl-5">

 <BlogItem
  title="The best remote UX and UI design conferences to attend in 2020"
  author="Ikram Sarker"
  published_at="22 January, 2022"
  comments="34"
  desc="Quickly drive clicks-and-mortar catalysts for change before vertical architectures. Credibly intermediate backend ideas for platform."
 />   

<BlogItem
  title="The best remote UX and UI design conferences to attend in 2020"
  author="Ikram Sarker"
  published_at="22 January, 2022"
  comments="34"
  desc="Quickly drive clicks-and-mortar catalysts for change before vertical architectures. Credibly intermediate backend ideas for platform."
 />  

<BlogItem
  title="The best remote UX and UI design conferences to attend in 2020"
  author="Ikram Sarker"
  published_at="22 January, 2022"
  comments="34"
  desc="Quickly drive clicks-and-mortar catalysts for change before vertical architectures. Credibly intermediate backend ideas for platform."
 />  

<BlogItem
  title="The best remote UX and UI design conferences to attend in 2020"
  author="Ikram Sarker"
  published_at="22 January, 2022"
  comments="34"
  desc="Quickly drive clicks-and-mortar catalysts for change before vertical architectures. Credibly intermediate backend ideas for platform."
 />  
  
</div>
</>
)
}
export default Blogs