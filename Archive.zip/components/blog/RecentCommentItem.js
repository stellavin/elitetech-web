import Link from "next/link"

const RecentCommentItem=()=>{
return(
<>
<div className="comment-box">
    <h4>
        <Link href="/"><a>Shahriar_Rafi <span>on</span> Branding involves developing strategy to create a point.</a></Link>
    </h4>
</div>
</>
)
}
export default RecentCommentItem