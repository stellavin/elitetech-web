import RecentCommentItem from "./RecentCommentItem"

const RecentComments=()=>{
return(
<>
<div className="single-cart">
    <div className="cart-title">
    <h2>Recent Comments</h2>
    </div>

    <RecentCommentItem />
    <RecentCommentItem />
    <RecentCommentItem />
    <RecentCommentItem />

</div>
</>
)
}
export default RecentComments