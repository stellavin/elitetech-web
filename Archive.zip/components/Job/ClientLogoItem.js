
const ClientLogoItem=(props)=>{
return(
<>
<div className="col">
    <div className="client-logo-box">
        <img src={props.img} alt=""/>
    </div>
</div>
</>
)
}
export default ClientLogoItem