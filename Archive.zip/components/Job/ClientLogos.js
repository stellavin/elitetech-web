import ClientLogoItem from "./ClientLogoItem"

const JobClientLogo=()=>{
return(
<>
<div className="client-logo-area mt-100 mb-76">
<div className="container">
<div className="row row-cols-2 row-cols-xl-6 row-cols-lg-6 row-cols-md-4 row-cols-sm-2">
    <ClientLogoItem
     img="assets/images/client-logo/c-logo-1.png"
    />
    <ClientLogoItem
     img="assets/images/client-logo/c-logo-1.png"
    />
    <ClientLogoItem
     img="assets/images/client-logo/c-logo-1.png"
    />
    <ClientLogoItem
     img="assets/images/client-logo/c-logo-1.png"
    />
    <ClientLogoItem
     img="assets/images/client-logo/c-logo-1.png"
    />
    <ClientLogoItem
     img="assets/images/client-logo/c-logo-1.png"
    />
</div>
</div>
</div>
</>
)
}
export default JobClientLogo