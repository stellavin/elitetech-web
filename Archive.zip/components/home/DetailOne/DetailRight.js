import React, { useState } from 'react';
import Link from "next/link"
import HomeDetailOne from "../../../constant/home/DetailOne"

const DetailRight=()=>{
    const [isParagraphVisible1, setIsParagraphVisible1] = useState(false);
    const [isParagraphVisible2, setIsParagraphVisible2] = useState(false);
    const [isParagraphVisible3, setIsParagraphVisible3] = useState(false);
    const [isParagraphVisible4, setIsParagraphVisible4] = useState(false);
    const [isParagraphVisible5, setIsParagraphVisible5] = useState(false);
    const [isParagraphVisible6, setIsParagraphVisible6] = useState(false);

    const toggleParagraphVisibility = (number) => {
        if (number === 1) setIsParagraphVisible1(!isParagraphVisible1);
        if (number === 2) setIsParagraphVisible2(!isParagraphVisible2);
        if (number === 3) setIsParagraphVisible3(!isParagraphVisible3);
        if (number === 4) setIsParagraphVisible4(!isParagraphVisible4);
        if (number === 5) setIsParagraphVisible5(!isParagraphVisible5);
        if (number === 6) setIsParagraphVisible6(!isParagraphVisible6);
    };



return(
<>
<div className="col-xxl-5 col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12 mobt-50">
    <div className="hrdd-section-title wow animate fadeInDown" data-wow-delay="100ms" data-wow-duration="1500ms">
        <h1 dangerouslySetInnerHTML={{__html: HomeDetailOne.Title}}></h1>
    </div>
    <div className="everything-info">
        <ul>
            <li onClick={ () => toggleParagraphVisibility(1)} className="wow animate fadeInUp" data-wow-delay="100ms" data-wow-duration="1500ms">{HomeDetailOne.Feature1}
            <span>
            {isParagraphVisible1 ? (
              <i className="bi bi-arrow-down"></i>
            ) : (
              <i className="bi bi-arrow-right"></i>
            )}</span>
            </li>
            {isParagraphVisible1 && (
            <p>
            Easily organize and access all your customer information, interactions, and history in one place. No more hunting through spreadsheets or email chains
            </p>
            )}
            <li onClick={ () => toggleParagraphVisibility(2)} className="wow animate fadeInUp" data-wow-delay="200ms" data-wow-duration="1500ms">{HomeDetailOne.Feature2} <span>
            {isParagraphVisible1 ? (
              <i className="bi bi-arrow-down"></i>
            ) : (
              <i className="bi bi-arrow-right"></i>
            )}</span></li>
            {isParagraphVisible2 && (
            <p>
            Streamline your sales process with automated workflows, lead tracking, and opportunity management. From lead generation to closing deals,we have got you covered.
            </p>
            )}
            <li onClick={ () => toggleParagraphVisibility(3)} className="wow animate fadeInUp" data-wow-delay="300ms" data-wow-duration="1500ms">{HomeDetailOne.Feature3} <span>
            {isParagraphVisible1 ? (
              <i className="bi bi-arrow-down"></i>
            ) : (
              <i className="bi bi-arrow-right"></i>
            )}</span></li>
            {isParagraphVisible3 && (
            <p>
            Create and manage marketing campaigns, track email engagement, and nurture leads with our integrated marketing tools. No need for separate software; it is all here.
            </p>
            )}
            <li onClick={ () => toggleParagraphVisibility(4)} className="wow animate fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">{HomeDetailOne.Feature4} <span>
            {isParagraphVisible1 ? (
              <i className="bi bi-arrow-down"></i>
            ) : (
              <i className="bi bi-arrow-right"></i>
            )}</span></li>
            {isParagraphVisible4 && (
            <p>
            Resolve customer issues promptly with our ticketing system and knowledge base. Provide top-notch support and keep your customers satisfied.
            </p>
            )}
            <li onClick={ () => toggleParagraphVisibility(5)} className="wow animate fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">{HomeDetailOne.Feature5} <span>
            {isParagraphVisible1 ? (
              <i className="bi bi-arrow-down"></i>
            ) : (
              <i className="bi bi-arrow-right"></i>
            )}</span></li>
            {isParagraphVisible5 && (
            <p>
            Tailor the CRM Platform to meet your unique needs. Customize fields, workflows, and reports to match your specific business processes.
            </p>
            )}
            <li onClick={ () => toggleParagraphVisibility(6)} className="wow animate fadeInUp" data-wow-delay="400ms" data-wow-duration="1500ms">{HomeDetailOne.Feature6} <span>
            {isParagraphVisible1 ? (
              <i className="bi bi-arrow-down"></i>
            ) : (
              <i className="bi bi-arrow-right"></i>
            )}</span></li>
            {isParagraphVisible6 && (
            <p>
            Protecting your data is our top priority. Our CRM platform is built with robust security measures to keep your information safe and confidential.
            </p>
            )}
        </ul>
    </div>
    
    <div className="hrrd-collaborate-btn-wrap wow animate fadeInUp" data-wow-delay="45ms" data-wow-duration="1500ms">
    <Link href="/contact"><a className="common-btn btn-hrrd-1">{HomeDetailOne.ActionBtn}</a></Link>
</div>
</div>
</>
)
}
export default DetailRight