
const HomeDetailOne={
    "Title":"Everything you <br/> need in one <span>place</span>",
    "Income":"Income This Month",
    "Price":"$ 50.36",
    "IncomeIncressed":"12%",
    "TotalLike":"398K",
    "MeetingTime":"Saturday, 8pm",
    "MeetingIcon1":"/assets/images/cart/hrrd-cart-1.png",
    "MeetingIcon2":"/assets/images/cart/hrrd-cart-2.png",
    "MeetingIcon3":"/assets/images/cart/hrrd-cart-3.png",
    "MeetingIcon4":"/assets/images/cart/hrrd-cart-4.png",
    "MeetingIcon5":"/assets/images/cart/hrrd-cart-5.png",
   

    "Feature1":"Comprehensive Contact Management",
    "Feature2":"Sales Made Simple",
    "Feature3":"Marketing at Your Fingertips",
    "Feature4":"Effortless Customer Support",
    "Feature5":"Customization",
    "Feature6":"Data Security",
    "ActionBtn":"Talk to us"
    
}
export default HomeDetailOne