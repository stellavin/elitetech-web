
const JobConstantOne={
  Title: {O:"Find Every",T:"Job",TR:"in One Platform"},
  SearchTags: ["Design","UI/UX","Product","Graphic"],
  CoverImg: "/assets/images/hero-img-1.png",
  CartTotalJob: "20k+ People Find Job!",
  CartLogo1: "assets/images/cart/cart-1.png",
  CartLogo2: "assets/images/cart/cart-2.png",
  CartLogo3: "assets/images/cart/cart-3.png",
  CartLogo4: "assets/images/cart/cart-4.png",
}
export default JobConstantOne