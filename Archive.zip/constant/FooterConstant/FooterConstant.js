
const FooterConstant={
    Logo: "/assets/images/logo.png",
    subTitle: "We are a dynamic team of CRM specialists, dedicated to providing cutting-edge solutions that propel your business to new heights.",
    GoogleLink: "/",
    LinkedinLink: "/",
    TwitterLink: "/",
    InstagramLink: "/",
    copyrightText: "Copyright©EliteCRK right reserved",
    copyrightTwo: "<p>Copyright©<a href='/'>chakri</a>.All right reserved</p>",
    phone: "971 5546 963",
    email: "info@elitecrmexperts.com",
    address: ["Belgium"]
}
export default FooterConstant