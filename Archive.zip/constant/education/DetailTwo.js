
const EducationDetailTwo={
    Title: "We Help to Create Possibility & Success in Your Career!",
    subTitle: "Continually administrate process-centric human capital rather than bleeding-edge methodologies. Distinctively supply accurate methods of empowerment before.",
    CoverImg : "/assets/images/education/success-students.png",
    VideoURL : "https://www.youtube.com/watch?v=ScMzIvxBSi4&t=17s",
    actionBtn: "Get Started Today"
}
export default EducationDetailTwo