
const EducationDetailOne={
    Title: "Start Your Future Education",
    subTitle: "Credibly redefine distinctive total linkage vis-a-vis multifunction data. Phosphorescently impact goal-oriented strategic",
    actionBtn: "Discover More",
    flotingMail :{title: "Congratulation!",subTitle: "You got a new email"},
    flotingStudent: {
        number: "40k +",title: "Happy Students",
        groupImg: "assets/images/education/avater-group.png"
    } 
}
export default EducationDetailOne