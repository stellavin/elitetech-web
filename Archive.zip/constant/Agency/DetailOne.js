
const AgencyConstantOne = {
   Title: "We help you to build your Business",
   subTitle: "Enthusiastically extend extensive customer service before best-of-breed convergence completely.",
   actionBtn: "Get a Quotes",
   reviewLabel: {
       title: "20k+ Customer Review",
       pic: "/assets/images/agency/avater-sm.png"
   },
   ProjectLable: {
       title: "Project Done",
       count: "3,258"
   }
}
export default AgencyConstantOne