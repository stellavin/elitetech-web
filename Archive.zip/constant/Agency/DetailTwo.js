
const AgencyConstantTwo = {
   Title1: "Make Your Website Design more Creative & Professional!",
   subTitle1: "Professionally evolve web-enabled resources and error-free . Interactively provide access to unique architectures rather than customized functionalities. Enthusiastically maintain user friendly processes through scalable process improvements. Conveniently foster mission-critical collaboration and idea-sharing",
   actionBtn1: "Learn More",
   CoverImg1: "/assets/images/agency/featured-img1.png",
   box1: {
       title: "People Who Trusted Us!",
       groupImg: "/assets/images/agency/avater-group-sm.png"
   },
   Title2: "Development Make Flexible foy Your Best Demand!",
   subTitle2: "Professionally evolve web-enabled resources and error-free . Interactively provide access to unique architectures rather than customized functionalities. Enthusiastically maintain user friendly processes through scalable process improvements. Conveniently foster mission-critical collaboration and idea-sharing",
   actionBtn2: "Learn More",
   CoverImg2: "assets/images/agency/featured-img2.png"
}

export default AgencyConstantTwo