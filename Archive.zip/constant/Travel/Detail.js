
const TravelDetail={
  Title: "Fuel Mind",
  TitleBordered: "Travel",
  subTitle: "Enthusiastically extend extensive customer service before best breed convergence completely.",
  LabelImage: "/assets/images/trip/tri-hero-label.png",
  CoverImage: "/assets/images/trip/hero-figure.png"
}
export default TravelDetail