
const HOMEHEADER={
  HomeTitle: "Best Platform to maximize growth and boost revenue.",
  ActionBtnText: "Book Demo",
  ConverImage: "/assets/images/hrrd-hero-img.png",
  Logo1: "/assets/images/client-logo/hrrd-client-logo-1.png",
  Logo2: "/assets/images/client-logo/hrrd-client-logo-2.png",
  Logo3: "/assets/images/client-logo/hrrd-client-logo-1.png",
  Logo4: "/assets/images/client-logo/hrrd-client-logo-2.png"
}
export default HOMEHEADER