const NavConstant = {
   Logo: "/assets/images/logo.png",
   LogoMobile: "/assets/images/logo.png"
}
export default NavConstant