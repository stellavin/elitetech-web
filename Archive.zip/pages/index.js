import HBottom from "../components/header/hbottom";
import HomeDetailOne from "../components/home/DetailOne";
import HomeDetailTwo from "../components/home/DetailTwo";
import Futured from "../components/home/futured";
import Header from "../components/layout/header";
import HomeNewsLater from "../components/home/NewsLater";
import Footer from "../components/layout/footer"

export default function Home() {
return (
<>
<header>
  <Header/>
  <HBottom/>
</header>
<Futured/>
<HomeDetailOne/>
<HomeDetailTwo/>
<HomeNewsLater/>
<Footer/>
</>
)
}

