"use strict";
exports.id = 794;
exports.ids = [794];
exports.modules = {

/***/ 8794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const NavConstant = {
    Logo: "/assets/images/logo.png",
    LogoMobile: "/assets/images/logo.png"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavConstant);


/***/ })

};
;