"use strict";
exports.id = 816;
exports.ids = [816];
exports.modules = {

/***/ 4816:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ about_TestimonialClient)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/layout/TestimonialClientList.js

const TestimonialClientList = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "single-client-testimonial text-center",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "client-testimonial-img",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: props.pic,
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "client-testimonial-info",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: props.name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: props.position
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "client-testimonial-rating",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "bi bi-star-fill"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "bi bi-star-fill"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "bi bi-star-fill"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "bi bi-star-fill"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "bi bi-star-fill"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: props.data
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const layout_TestimonialClientList = (TestimonialClientList);

// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./components/about/TestimonialClient.js




const TestimonialClient = ()=>{
    const SliderSetting = {
        dots: true,
        speed: 1000,
        slidesToShow: 4,
        slidesToScroll: 1,
        arrows: false,
        pauseOnDotsHover: true,
        responsive: [
            {
                breakpoint: 1224,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 800,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    const testimonials = [
        "Incredible CRM! Boosted our sales and efficiency. A game-changer!",
        "CRM made a big impact. Streamlined processes and improved customer relationships.",
        "Outstanding CRM. Enhanced teamwork and customer satisfaction. Highly recommended!",
        "CRM exceeded expectations. Increased productivity and revenue. Impressive results!",
        "CRM transformed our business. Simplified tasks and fostered customer loyalty."
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "about-testimonial-area",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xxl-5 col-xl-5 col-lg-6 col-md-12 col-sm-12 col-12",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hrdd-section-title text-capitalize",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                        children: [
                                            "What  our ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "client"
                                            }),
                                            " say"
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xxl-5 col-xl-5 col-lg-6 col-md-12 col-sm-12 col-12 mobt-24",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "section-text wow animate flipInX",
                                    "data-wow-delay": "300ms",
                                    "data-wow-duration": "1500ms",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        children: "Trusted by more than 40,000 customers worldwide since 2010, our CRM service is nothing short of amazing. From day one, we have made it our mission to stand out among the stars in the CRM dominion."
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "row pt-50",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "inner-slide-wrap",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                                    ...SliderSetting,
                                    children: testimonials.map((data, i)=>/*#__PURE__*/ jsx_runtime_.jsx(layout_TestimonialClientList, {
                                            data: data
                                        }, i)
                                    )
                                })
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const about_TestimonialClient = (TestimonialClient);


/***/ })

};
;