"use strict";
exports.id = 369;
exports.ids = [369];
exports.modules = {

/***/ 8369:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ futured)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/home/futured/item.js

const FutureItem = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 wow animate fadeInUp",
        "data-wow-delay": props.AnimeDelay,
        "data-wow-duration": "1500ms",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "featured-box",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "featured-icon",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: props.icon,
                        alt: ""
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "featured-content",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            children: props.title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: props.desc
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const item = (FutureItem);

;// CONCATENATED MODULE: ./components/home/futured.js


const Futured = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "featured-area positioning pb-76",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "row",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "hrdd-section-title text-center wow animate fadeInDown",
                                    "data-wow-delay": "100ms",
                                    "data-wow-duration": "1500ms",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Features"
                                            }),
                                            " We ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                            " Provide for You"
                                        ]
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row justify-content-center mt-50",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(item, {
                                    AnimeDelay: "400ms",
                                    icon: "/assets/images/icon/featured-icon-1.png",
                                    title: "Dashboard",
                                    desc: "Effective Data Visualization"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(item, {
                                    AnimeDelay: "500ms",
                                    icon: "/assets/images/icon/featured-icon-4.png",
                                    title: "Lead Management",
                                    desc: "Capture, track, and convert leads seamlessly."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(item, {
                                    AnimeDelay: "600ms",
                                    icon: "/assets/images/icon/featured-icon-2.png",
                                    title: "Real-Time Reports",
                                    desc: "Gain valuable insights with detailed analytics"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(item, {
                                    AnimeDelay: "700ms",
                                    icon: "/assets/images/icon/featured-icon-3.png",
                                    title: "Sales Tracking",
                                    desc: "Monitor sales pipelines and close deals faster."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(item, {
                                    AnimeDelay: "800ms",
                                    icon: "/assets/images/icon/featured-icon-5.png",
                                    title: "Customer Communication",
                                    desc: "Engage and build lasting relationships with customers."
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: "shape featured-shape",
                    src: "assets/images/shape/feasured-hrrd.png",
                    alt: ""
                })
            ]
        })
    });
};
/* harmony default export */ const futured = (Futured);


/***/ })

};
;